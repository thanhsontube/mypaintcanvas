package com.example.testfromgraphicsapi;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class MainActivityBk extends Activity {

	private MyView rootView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		rootView = new MyView(this);
		setContentView(rootView);

		mPaint = new Paint();
		mPaint.setAntiAlias(true);
		mPaint.setDither(true);
		mPaint.setColor(0xFFFF0000);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeJoin(Paint.Join.ROUND);
		mPaint.setStrokeCap(Paint.Cap.ROUND);
		mPaint.setStrokeWidth(12);
	}

	private Paint mPaint;

	public void colorChanged(int color) {
		mPaint.setColor(color);
	}

	public class MyView extends View {

		private Bitmap mBitmap;
		private Canvas mCanvas;
		private Path mPath;
		private Paint mBitmapPaint;

		private List<Path> listPaths = new ArrayList<Path>();
		private List<Path> listPathsRedo = new ArrayList<Path>();
		
		public MyView(Context c) {
			super(c);
			mPath = new Path();
			mBitmapPaint = new Paint(Paint.DITHER_FLAG);
		}

		@Override
		protected void onSizeChanged(int w, int h, int oldw, int oldh) {
			super.onSizeChanged(w, h, oldw, oldh);
			mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
			mCanvas = new Canvas(mBitmap);
		}

		@Override
		protected void onDraw(Canvas canvas) {
			Log.d("TEST", "onDraw");
			canvas.drawColor(0xFFAAAAAA);
			canvas.drawBitmap(mBitmap, 0, 0, mBitmapPaint);
			canvas.drawPath(mPath, mPaint);
		}

		private float mX, mY;
		private static final float TOUCH_TOLERANCE = 4;

		private void touch_start(float x, float y) {
			mPath.reset();
			mPath.moveTo(x, y);
			mX = x;
			mY = y;
		}

		private void touch_move(float x, float y) {
			float dx = Math.abs(x - mX);
			float dy = Math.abs(y - mY);
			if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
				mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
				mX = x;
				mY = y;
			}
		}

		private void touch_up() {
			mPath.lineTo(mX, mY);
			Path newPath = new Path(mPath);
			listPaths.add(newPath);
			mCanvas.drawPath(mPath, mPaint);
			mPath.reset();

			if (isUndo) {
				listPathsRedo.clear();
				isUndo = false;
			}
		}

		private boolean isUndo = false;

		public void undo() {
			if (listPaths.size() == 0) {
				Toast.makeText(MainActivityBk.this, "Stack empty",
						Toast.LENGTH_SHORT).show();
				return;
			}
			isUndo = true;
			listPathsRedo.add(listPaths.get(listPaths.size() - 1));
			listPaths.remove(listPaths.size() - 1);
			if (listPaths.size() > 0) {
				mPath = new Path(listPaths.get(listPaths.size() - 1));
			} else {
				mPath = new Path();
			}
			invalidate();
		}

		public void redo() {
			if (listPathsRedo.size() == 0) {
				Toast.makeText(MainActivityBk.this, "At Top, can not redo",
						Toast.LENGTH_SHORT).show();
				return;
			}
			listPaths.add(listPathsRedo.get(listPathsRedo.size() - 1));
			listPathsRedo.remove(listPathsRedo.size() - 1);
			mPath = new Path(listPaths.get(listPaths.size() - 1));
			invalidate();
		}

		@Override
		public boolean onTouchEvent(MotionEvent event) {
			float x = event.getX();
			float y = event.getY();
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				touch_start(x, y);
				invalidate();
				break;
			case MotionEvent.ACTION_MOVE:
				touch_move(x, y);
				invalidate();
				break;
			case MotionEvent.ACTION_UP:
				touch_up();
				invalidate();
				break;
			}
			return true;
		}
	}

	private static final int DRAW_MENU_ID = Menu.FIRST;
	private static final int UNDO_MENU_ID = Menu.FIRST + 1;
	private static final int REDO_MENU_ID = Menu.FIRST + 2;
	private static final int ERASE_MENU_ID = Menu.FIRST + 3;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, DRAW_MENU_ID, 0, "DRAW").setShowAsActionFlags(
				MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, UNDO_MENU_ID, 0, "UNDO").setShowAsActionFlags(
				MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, REDO_MENU_ID, 0, "REDO").setShowAsActionFlags(
				MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, ERASE_MENU_ID, 0, "ERASE").setShowAsActionFlags(
				MenuItem.SHOW_AS_ACTION_ALWAYS);
		return true;
	}

	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		super.onPrepareOptionsMenu(menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		mPaint.setXfermode(null);
		mPaint.setAlpha(0xFF);
		switch (item.getItemId()) {
		case DRAW_MENU_ID:
			mPaint.setXfermode(null);
			return true;
		case UNDO_MENU_ID:
			rootView.undo();
			return true;
		case REDO_MENU_ID:
			rootView.redo();
			return true;
		case ERASE_MENU_ID:
			mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
